<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class fooController extends Controller
{
   

 public function foo(){
}

 public function foo(){
}

 public function foo(){
}

 public function foo(){
}
 }