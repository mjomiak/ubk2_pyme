@extends('layouts.app')

@section('content')

{!! MigasFacade::render('ubk2/trab/read') !!}

<div class="row" style="margin-top: 1em;">
    <div class="col-1"></div>
    <div class="col-10">




        
           @if(session('success'))
            <div id="msg_exito" class="alert alert-success">
                {!! session('success') !!}
            </div>
        
            <script>
                // Mostrar el div inicialmente
                document.getElementById('msg_exito').style.display = 'block';
        
                // Ocultar el div después de 5 segundos con un efecto de desvanecimiento
                setTimeout(function () {
                    var miDiv = document.getElementById('msg_exito');
                    miDiv.style.transition = 'opacity 1s ease-in-out';
                    miDiv.style.opacity = '0';
        
                    // Puedes agregar más lógica después de que se haya completado el desvanecimiento
                    setTimeout(function () {
                        miDiv.style.display = 'none';
                    }, 5000); // 1000 ms = 1 segundo (corresponde a la duración de la transición)
                }, 1000); // 5000 ms = 5 segundos
            </script>
        
        
        
            @endif
        
            @if(session('error'))
            <div id="msg_error" class="alert alert-danger">
                {!! session('error') !!}
            </div>
            <script>
                // Mostrar el div inicialmente
                document.getElementById('msg_error').style.display = 'block';
        
                // Ocultar el div después de 5 segundos con un efecto de desvanecimiento
                setTimeout(function () {
                    var miDiv = document.getElementById('msg_error');
                    miDiv.style.transition = 'opacity 1s ease-in-out';
                    miDiv.style.opacity = '0';
        
                    // Puedes agregar más lógica después de que se haya completado el desvanecimiento
                    setTimeout(function () {
                        miDiv.style.display = 'none';
                    }, 1000); // 1000 ms = 1 segundo (corresponde a la duración de la transición)
                }, 5000); // 5000 ms = 5 segundos
            </script>
        
            @endif
        
        
        
        <h3>Listado de trabajadores</h3>




<a href="{{route($rutas['c'])}}" title="Crea un nuevo Trabajador (Usuario App)">Nuevo</a> <br>
<a href="#" title="Permite la carga masiva desde una planilla de cálculo">Carga Masiva</a> 

<table  id="listado">
<thead>
    <tr>
        <th>#</th>
        <th>R.U.N.</th>
        <th>Nombre Completo</th>
        <th>Correo</th>
        <th>Móvil</th>
        <th>Opciones</th>
       
    </tr>
</thead>
<tbody>

    @foreach($trabajadores as $t)
    <tr>
        <td>{{$loop->iteration}}</td>
        <td>{{$t->rut}}-{{$t->dv}}</td>
        <td>{{$t->nombreCompleto}}</td>
        <td>{{$t->correo}}</td>
        <td>{{$t->movil}}</td>
        <td> <a href="{{route($rutas['u'],['id'=>$t->id])}}">Modificar</a>
         
            <a href="{{route($rutas['d'],['id'=>$t->id])}}">Baja</a>
            <a href="{{route($rutas['rd'],['id'=>$t->id])}}">Elim. tot</a>

        </td>

    </tr>
   
    @endforeach


</tbody>

</table>
</div>
</div>

<script>
    $(document).ready( function () {
        $('#listado').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Spanish.json" // Ruta al archivo de idioma
            },
            "columnDefs": [
                { "width": "20px", "targets": 0 },
               
            ]
        });
    });
</script>






<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>




<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">



@endsection