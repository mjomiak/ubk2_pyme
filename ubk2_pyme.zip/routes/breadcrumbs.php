
<?php

use Diglactic\Breadcrumbs\Breadcrumbs;


use Diglactic\Breadcrumbs\Generator as BreadcrumbTrail;


// Home
Breadcrumbs::for('home', function ($trail) {
    
    $trail->push('Inicio', route('home',['nav'=>true]));
 
});

// Home > About
Breadcrumbs::for('SigmaListadoUsuarios', function ($trail) {
    $trail->parent('home');
    $trail->push('Sistema / Usuarios', route('SigmaListadoUsuarios'));
});

?>
