

<?php

//Rutas mòdulo ubicados


use Illuminate\Support\Facades\Route;

